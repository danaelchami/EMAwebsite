// background.js
import { registerHandlers } from './handlers.js';

// just wire everything up
registerHandlers();
